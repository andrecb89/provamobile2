package com.example.pedrapapeltesoura

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
