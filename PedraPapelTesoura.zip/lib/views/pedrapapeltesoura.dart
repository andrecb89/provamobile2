import 'dart:math';

import 'package:flutter/material.dart';

class PedraPapelTesoura extends StatefulWidget {
  const PedraPapelTesoura({Key? key}) : super(key: key);

  @override
  State<PedraPapelTesoura> createState() => _PedraPapelTesouraState();
}

class _PedraPapelTesouraState extends State<PedraPapelTesoura> {
  var escolhaPc = 0;
  var textPc = 'APERTE AQUI';
  var textoPc = '';
  int option = 0;
  var scorePlayer = 0;
  var scorePc = 0;
  var resultado = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightGreen,
      ),
      body: Column(
        children: [
          Center(
            child: Text('Sua jogada'),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              GestureDetector(
                onTap: () {
                  setState(() {
                    option = 0;
                    escolhaPc = Random().nextInt(3);
                    if (escolhaPc == 0) {
                      textPc = 'Pedra';
                    } else if (escolhaPc == 1) {
                      textPc = 'Papel';
                    } else {
                      textPc = 'Tesoura';
                    }
                    textoPc = textPc;

                    if (escolhaPc == 0) {
                      resultado = 'Empatou';
                    } else if (escolhaPc == 2) {
                      scorePlayer++;
                      resultado = 'Ganhou';
                    } else {
                      resultado = 'Perdeu';
                      scorePc++;
                    }
                  });
                },
                child: Container(
                  width: 100,
                  height: 100,
                  color: Colors.grey,
                  child: Text('PEDRA'),
                ),
              ),
              GestureDetector(
                onTap: () {
                  setState(() {
                    option = 1;
                    escolhaPc = Random().nextInt(3);
                    if (escolhaPc == 0) {
                      textPc = 'Pedra';
                    } else if (escolhaPc == 1) {
                      textPc = 'Papel';
                    } else {
                      textPc = 'Tesoura';
                    }
                    textoPc = textPc;
                    if (escolhaPc == 0) {
                      scorePlayer++;
                      resultado = 'Ganhou';
                    } else if (escolhaPc == 1) {
                      resultado = 'Empatou';
                    } else if (escolhaPc == 2) {
                      resultado = 'Perdeu';
                      scorePc++;
                    }
                  });
                },
                child: Container(
                  width: 100,
                  height: 100,
                  color: Colors.grey,
                  child: Text('PAPEL'),
                ),
              ),
              GestureDetector(
                onTap: () {
                  setState(() {
                    option = 2;
                    escolhaPc = Random().nextInt(3);
                    // print(escolhaPc);
                    if (escolhaPc == 0) {
                      textPc = 'Pedra';
                    } else if (escolhaPc == 1) {
                      textPc = 'Papel';
                    } else {
                      textPc = 'Tesoura';
                    }
                    textoPc = textPc;
                    if (escolhaPc == 1) {
                      resultado = "Ganhou";
                      scorePc++;
                    } else if (escolhaPc == 2) {
                      resultado = 'Empatou';
                    } else {
                      scorePlayer++;
                      resultado = "Perdeu";
                    }
                  });
                },
                child: Container(
                  width: 100,
                  height: 100,
                  color: Colors.grey,
                  child: Text('TESOURA'),
                ),
              ),
            ],
          ),
          Text('Jogada do computador'),
          Container(
            width: 100,
            height: 100,
            color: Colors.grey,
            child: Text(textoPc),
          ),
          Text('Resultado'),
          Text(resultado),
          Text('Placar'),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 300,
                height: 100,
                color: Colors.grey,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Column(
                        children: [Text('Você'), Text(scorePlayer.toString())],
                      ),
                    ),
                    Container(
                      child: Column(
                        children: [Text('PC'), Text(scorePc.toString())],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}
